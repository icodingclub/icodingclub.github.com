package com.icodingclub.jms.service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;


/**
 * @author Praveen k Singh
 * 
 */
public class MsgSenderService
{

	private static final Logger LOG = Logger.getLogger(MsgSenderService.class);
	
	private JmsTemplate jmsTemplate;

	public void sendMessage(final String msg) throws JMSException
	{
		jmsTemplate.send(new MessageCreator()
		{
			public Message createMessage(Session session) throws JMSException
			{
				LOG.info("SENDING: " + msg);
				TextMessage message = session.createTextMessage(msg);
				return message;
			}
		});
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}

}

package com.icodingclub.jms.web;

import java.io.IOException;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.icodingclub.jms.service.AMQMsgSenderService;


/**
 * @author Praveen k Singh
 * 
 */
@Controller
public class ProducerController
{

	private static final Logger LOG = Logger.getLogger(ProducerController.class);

	@Autowired
	private AMQMsgSenderService messageSenderService;

	@RequestMapping(value = "/amqTest.html", method = RequestMethod.GET)
	public void amqLoadTest() throws IOException
	{
		LOG.info("Inside Controller");

		Calendar cal = Calendar.getInstance();
		try
		{
			messageSenderService.sendMessage("Message on: " + cal);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}

package com.icodingclub.jmx;

import java.io.PrintStream;
import java.util.Date;
import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import org.hornetq.api.jms.management.JMSQueueControl;

public class TestJMX
{

	public static void main(String[] args) throws Throwable
	{

		JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://localhost:9004/jmxrmi");
		JMXConnector connector = JMXConnectorFactory.connect(url, null);
		connector.connect();
		ObjectName on = new ObjectName("org.hornetq:module=JMS,type=Queue,name=\"testQueue\"");

		MBeanServerConnection mbsc = connector.getMBeanServerConnection();

		JMSQueueControl queueControl = (JMSQueueControl) MBeanServerInvocationHandler
				.newProxyInstance(mbsc, on, JMSQueueControl.class, false);

		System.out.println("MessagesAdded: " + queueControl.getMessagesAdded());

		connector.close();
	}
}